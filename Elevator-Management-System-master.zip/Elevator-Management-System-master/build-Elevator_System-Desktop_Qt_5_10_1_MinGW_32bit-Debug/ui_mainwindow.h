/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.10.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLCDNumber>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenu>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QHBoxLayout *horizontalLayout;
    QGroupBox *groupBox_3;
    QPushButton *pushButton_3;
    QPushButton *pushButton_4;
    QPushButton *pushButton_5;
    QPushButton *pushButton_6;
    QPushButton *pushButton_7;
    QPushButton *pushButton_8;
    QPushButton *pushButton_9;
    QPushButton *pushButton_2;
    QPushButton *pushButton;
    QPushButton *pushButton_11;
    QPushButton *pushButton_12;
    QPushButton *pushButton_13;
    QPushButton *pushButton_14;
    QPushButton *pushButton_15;
    QPushButton *pushButton_16;
    QPushButton *pushButton_17;
    QPushButton *pushButton_18;
    QPushButton *pushButton_19;
    QPushButton *pushButton_20;
    QLCDNumber *lcdNumber;
    QLCDNumber *lcdNumber_2;
    QLCDNumber *lcdNumber_3;
    QLCDNumber *lcdNumber_4;
    QLCDNumber *lcdNumber_5;
    QPushButton *pushButton_21;
    QLCDNumber *lcdNumber_6;
    QPushButton *pushButton_10;
    QGroupBox *groupBox_2;
    QLCDNumber *lcdNumber_7;
    QPushButton *pushButton_22;
    QPushButton *pushButton_23;
    QPushButton *pushButton_24;
    QLCDNumber *lcdNumber_8;
    QLCDNumber *lcdNumber_9;
    QPushButton *pushButton_25;
    QPushButton *pushButton_26;
    QPushButton *pushButton_27;
    QPushButton *pushButton_28;
    QPushButton *pushButton_29;
    QPushButton *pushButton_30;
    QPushButton *pushButton_31;
    QPushButton *pushButton_32;
    QPushButton *Floor2_1;
    QPushButton *pushButton_34;
    QPushButton *pushButton_35;
    QPushButton *pushButton_36;
    QPushButton *pushButton_37;
    QPushButton *Floor2_2;
    QPushButton *pushButton_39;
    QLCDNumber *lcdNumber_10;
    QPushButton *pushButton_40;
    QPushButton *NextButton2;
    QLCDNumber *lcdNumber_11;
    QLCDNumber *lcdNumber_12;
    QPushButton *pushButton_42;
    QGroupBox *groupBox_5;
    QLCDNumber *lcd3_2;
    QPushButton *FLOOR1U;
    QPushButton *FLOOR5D;
    QPushButton *FLOOR2U;
    QLCDNumber *lcd3_1;
    QLCDNumber *lcd3_6;
    QPushButton *Floor3_3;
    QPushButton *FLOOR3D;
    QPushButton *FLOOR2D;
    QPushButton *FLOOR4;
    QPushButton *FLOOR1;
    QPushButton *FLOOR4D;
    QPushButton *Floor3_E;
    QPushButton *FLOOR3;
    QPushButton *Floor3_1;
    QPushButton *FLOOR3U;
    QPushButton *Floor3_4;
    QPushButton *FLOOR5;
    QPushButton *FLOOR4U;
    QPushButton *Floor3_2;
    QPushButton *Floor3_A;
    QLCDNumber *lcd3_4;
    QPushButton *Floor3_5;
    QPushButton *NextButton3;
    QLCDNumber *lcd3_5;
    QLCDNumber *lcd3_3;
    QPushButton *FLOOR2;
    QGroupBox *groupBox_6;
    QLCDNumber *lcdNumber_19;
    QPushButton *pushButton_64;
    QPushButton *pushButton_65;
    QPushButton *pushButton_66;
    QLCDNumber *lcdNumber_20;
    QLCDNumber *lcdNumber_21;
    QPushButton *pushButton_67;
    QPushButton *pushButton_68;
    QPushButton *pushButton_69;
    QPushButton *pushButton_70;
    QPushButton *pushButton_71;
    QPushButton *pushButton_72;
    QPushButton *pushButton_73;
    QPushButton *pushButton_74;
    QPushButton *pushButton_75;
    QPushButton *pushButton_76;
    QPushButton *pushButton_77;
    QPushButton *pushButton_78;
    QPushButton *pushButton_79;
    QPushButton *pushButton_80;
    QPushButton *pushButton_81;
    QLCDNumber *lcdNumber_22;
    QPushButton *pushButton_82;
    QPushButton *pushButton_83;
    QLCDNumber *lcdNumber_23;
    QLCDNumber *lcdNumber_24;
    QPushButton *pushButton_84;
    QGroupBox *groupBox;
    QLCDNumber *lcd5_2;
    QPushButton *FLOOR51U;
    QPushButton *FLOOR55D;
    QPushButton *FLOOR52U;
    QLCDNumber *lcd5_1;
    QLCDNumber *lcd5_6;
    QPushButton *Floor5_3;
    QPushButton *FLOOR53D;
    QPushButton *FLOOR52D;
    QPushButton *FLOOR54;
    QPushButton *FLOOR51;
    QPushButton *FLOOR54D;
    QPushButton *Floor5_E;
    QPushButton *FLOOR53;
    QPushButton *Floor5_1;
    QPushButton *FLOOR53U;
    QPushButton *Floor5_4;
    QPushButton *FLOOR55;
    QPushButton *FLOOR54U;
    QPushButton *Floor5_2;
    QPushButton *Floor5_A;
    QLCDNumber *lcd5_4;
    QPushButton *Floor5_5;
    QPushButton *NextButton5;
    QLCDNumber *lcd5_5;
    QLCDNumber *lcd5_3;
    QPushButton *FLOOR52;
    QGroupBox *groupBox_4;
    QLCDNumber *lcdNumber_37;
    QPushButton *pushButton_126;
    QPushButton *pushButton_127;
    QPushButton *pushButton_128;
    QLCDNumber *lcdNumber_38;
    QLCDNumber *lcdNumber_39;
    QPushButton *pushButton_129;
    QPushButton *pushButton_130;
    QPushButton *pushButton_131;
    QPushButton *pushButton_132;
    QPushButton *pushButton_133;
    QPushButton *pushButton_134;
    QPushButton *pushButton_135;
    QPushButton *pushButton_136;
    QPushButton *pushButton_137;
    QPushButton *pushButton_138;
    QPushButton *pushButton_139;
    QPushButton *pushButton_140;
    QPushButton *pushButton_141;
    QPushButton *pushButton_142;
    QPushButton *pushButton_143;
    QLCDNumber *lcdNumber_40;
    QPushButton *pushButton_144;
    QPushButton *pushButton_145;
    QLCDNumber *lcdNumber_41;
    QLCDNumber *lcdNumber_42;
    QPushButton *pushButton_146;
    QMenuBar *menuBar;
    QMenu *menuElevator_Management_System;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QStringLiteral("MainWindow"));
        MainWindow->resize(980, 519);
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        horizontalLayout = new QHBoxLayout(centralWidget);
        horizontalLayout->setSpacing(6);
        horizontalLayout->setContentsMargins(11, 11, 11, 11);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        groupBox_3 = new QGroupBox(centralWidget);
        groupBox_3->setObjectName(QStringLiteral("groupBox_3"));
        pushButton_3 = new QPushButton(groupBox_3);
        pushButton_3->setObjectName(QStringLiteral("pushButton_3"));
        pushButton_3->setGeometry(QRect(40, 300, 71, 51));
        pushButton_3->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_4 = new QPushButton(groupBox_3);
        pushButton_4->setObjectName(QStringLiteral("pushButton_4"));
        pushButton_4->setGeometry(QRect(10, 300, 21, 23));
        pushButton_5 = new QPushButton(groupBox_3);
        pushButton_5->setObjectName(QStringLiteral("pushButton_5"));
        pushButton_5->setGeometry(QRect(40, 240, 71, 51));
        pushButton_5->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_6 = new QPushButton(groupBox_3);
        pushButton_6->setObjectName(QStringLiteral("pushButton_6"));
        pushButton_6->setGeometry(QRect(10, 240, 21, 23));
        pushButton_7 = new QPushButton(groupBox_3);
        pushButton_7->setObjectName(QStringLiteral("pushButton_7"));
        pushButton_7->setGeometry(QRect(40, 180, 71, 51));
        pushButton_7->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_8 = new QPushButton(groupBox_3);
        pushButton_8->setObjectName(QStringLiteral("pushButton_8"));
        pushButton_8->setGeometry(QRect(10, 180, 21, 23));
        pushButton_9 = new QPushButton(groupBox_3);
        pushButton_9->setObjectName(QStringLiteral("pushButton_9"));
        pushButton_9->setGeometry(QRect(40, 120, 71, 51));
        pushButton_9->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_2 = new QPushButton(groupBox_3);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setGeometry(QRect(40, 360, 71, 51));
        pushButton_2->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        pushButton = new QPushButton(groupBox_3);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setGeometry(QRect(10, 370, 21, 23));
        pushButton->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        pushButton_11 = new QPushButton(groupBox_3);
        pushButton_11->setObjectName(QStringLiteral("pushButton_11"));
        pushButton_11->setGeometry(QRect(10, 330, 21, 23));
        pushButton_12 = new QPushButton(groupBox_3);
        pushButton_12->setObjectName(QStringLiteral("pushButton_12"));
        pushButton_12->setGeometry(QRect(10, 270, 21, 23));
        pushButton_13 = new QPushButton(groupBox_3);
        pushButton_13->setObjectName(QStringLiteral("pushButton_13"));
        pushButton_13->setGeometry(QRect(10, 210, 21, 23));
        pushButton_14 = new QPushButton(groupBox_3);
        pushButton_14->setObjectName(QStringLiteral("pushButton_14"));
        pushButton_14->setGeometry(QRect(10, 130, 21, 23));
        pushButton_15 = new QPushButton(groupBox_3);
        pushButton_15->setObjectName(QStringLiteral("pushButton_15"));
        pushButton_15->setGeometry(QRect(20, 30, 20, 20));
        pushButton_16 = new QPushButton(groupBox_3);
        pushButton_16->setObjectName(QStringLiteral("pushButton_16"));
        pushButton_16->setGeometry(QRect(50, 30, 20, 20));
        pushButton_17 = new QPushButton(groupBox_3);
        pushButton_17->setObjectName(QStringLiteral("pushButton_17"));
        pushButton_17->setGeometry(QRect(50, 60, 20, 20));
        pushButton_18 = new QPushButton(groupBox_3);
        pushButton_18->setObjectName(QStringLiteral("pushButton_18"));
        pushButton_18->setGeometry(QRect(20, 60, 20, 20));
        pushButton_19 = new QPushButton(groupBox_3);
        pushButton_19->setObjectName(QStringLiteral("pushButton_19"));
        pushButton_19->setGeometry(QRect(80, 60, 20, 20));
        pushButton_20 = new QPushButton(groupBox_3);
        pushButton_20->setObjectName(QStringLiteral("pushButton_20"));
        pushButton_20->setGeometry(QRect(80, 30, 20, 20));
        lcdNumber = new QLCDNumber(groupBox_3);
        lcdNumber->setObjectName(QStringLiteral("lcdNumber"));
        lcdNumber->setGeometry(QRect(120, 370, 25, 30));
        lcdNumber->setLayoutDirection(Qt::LeftToRight);
        lcdNumber->setAutoFillBackground(false);
        lcdNumber->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber->setSmallDecimalPoint(false);
        lcdNumber->setDigitCount(1);
        lcdNumber->setProperty("value", QVariant(0));
        lcdNumber->setProperty("intValue", QVariant(0));
        lcdNumber_2 = new QLCDNumber(groupBox_3);
        lcdNumber_2->setObjectName(QStringLiteral("lcdNumber_2"));
        lcdNumber_2->setGeometry(QRect(120, 310, 25, 30));
        lcdNumber_2->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_2->setAutoFillBackground(false);
        lcdNumber_2->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_2->setSmallDecimalPoint(false);
        lcdNumber_2->setDigitCount(1);
        lcdNumber_3 = new QLCDNumber(groupBox_3);
        lcdNumber_3->setObjectName(QStringLiteral("lcdNumber_3"));
        lcdNumber_3->setGeometry(QRect(120, 250, 25, 30));
        lcdNumber_3->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_3->setAutoFillBackground(false);
        lcdNumber_3->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_3->setSmallDecimalPoint(false);
        lcdNumber_3->setDigitCount(1);
        lcdNumber_4 = new QLCDNumber(groupBox_3);
        lcdNumber_4->setObjectName(QStringLiteral("lcdNumber_4"));
        lcdNumber_4->setGeometry(QRect(120, 190, 25, 30));
        lcdNumber_4->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_4->setAutoFillBackground(false);
        lcdNumber_4->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_4->setSmallDecimalPoint(false);
        lcdNumber_4->setDigitCount(1);
        lcdNumber_5 = new QLCDNumber(groupBox_3);
        lcdNumber_5->setObjectName(QStringLiteral("lcdNumber_5"));
        lcdNumber_5->setGeometry(QRect(120, 130, 25, 30));
        lcdNumber_5->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_5->setAutoFillBackground(false);
        lcdNumber_5->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_5->setSmallDecimalPoint(false);
        lcdNumber_5->setDigitCount(1);
        pushButton_21 = new QPushButton(groupBox_3);
        pushButton_21->setObjectName(QStringLiteral("pushButton_21"));
        pushButton_21->setGeometry(QRect(110, 60, 20, 20));
        lcdNumber_6 = new QLCDNumber(groupBox_3);
        lcdNumber_6->setObjectName(QStringLiteral("lcdNumber_6"));
        lcdNumber_6->setGeometry(QRect(120, 30, 25, 30));
        lcdNumber_6->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_6->setAutoFillBackground(false);
        lcdNumber_6->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_6->setSmallDecimalPoint(false);
        lcdNumber_6->setDigitCount(1);
        pushButton_10 = new QPushButton(groupBox_3);
        pushButton_10->setObjectName(QStringLiteral("pushButton_10"));
        pushButton_10->setGeometry(QRect(40, 0, 75, 23));

        horizontalLayout->addWidget(groupBox_3);

        groupBox_2 = new QGroupBox(centralWidget);
        groupBox_2->setObjectName(QStringLiteral("groupBox_2"));
        lcdNumber_7 = new QLCDNumber(groupBox_2);
        lcdNumber_7->setObjectName(QStringLiteral("lcdNumber_7"));
        lcdNumber_7->setGeometry(QRect(120, 310, 25, 30));
        lcdNumber_7->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_7->setAutoFillBackground(false);
        lcdNumber_7->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_7->setSmallDecimalPoint(false);
        lcdNumber_7->setDigitCount(1);
        pushButton_22 = new QPushButton(groupBox_2);
        pushButton_22->setObjectName(QStringLiteral("pushButton_22"));
        pushButton_22->setGeometry(QRect(10, 370, 21, 23));
        pushButton_22->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        pushButton_23 = new QPushButton(groupBox_2);
        pushButton_23->setObjectName(QStringLiteral("pushButton_23"));
        pushButton_23->setGeometry(QRect(10, 130, 21, 23));
        pushButton_24 = new QPushButton(groupBox_2);
        pushButton_24->setObjectName(QStringLiteral("pushButton_24"));
        pushButton_24->setGeometry(QRect(10, 300, 21, 23));
        lcdNumber_8 = new QLCDNumber(groupBox_2);
        lcdNumber_8->setObjectName(QStringLiteral("lcdNumber_8"));
        lcdNumber_8->setGeometry(QRect(120, 370, 25, 30));
        lcdNumber_8->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_8->setAutoFillBackground(false);
        lcdNumber_8->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_8->setSmallDecimalPoint(false);
        lcdNumber_8->setDigitCount(1);
        lcdNumber_8->setProperty("value", QVariant(0));
        lcdNumber_8->setProperty("intValue", QVariant(0));
        lcdNumber_9 = new QLCDNumber(groupBox_2);
        lcdNumber_9->setObjectName(QStringLiteral("lcdNumber_9"));
        lcdNumber_9->setGeometry(QRect(120, 30, 25, 30));
        lcdNumber_9->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_9->setAutoFillBackground(false);
        lcdNumber_9->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_9->setSmallDecimalPoint(false);
        lcdNumber_9->setDigitCount(1);
        pushButton_25 = new QPushButton(groupBox_2);
        pushButton_25->setObjectName(QStringLiteral("pushButton_25"));
        pushButton_25->setGeometry(QRect(80, 30, 20, 20));
        pushButton_26 = new QPushButton(groupBox_2);
        pushButton_26->setObjectName(QStringLiteral("pushButton_26"));
        pushButton_26->setGeometry(QRect(10, 270, 21, 23));
        pushButton_27 = new QPushButton(groupBox_2);
        pushButton_27->setObjectName(QStringLiteral("pushButton_27"));
        pushButton_27->setGeometry(QRect(10, 330, 21, 23));
        pushButton_28 = new QPushButton(groupBox_2);
        pushButton_28->setObjectName(QStringLiteral("pushButton_28"));
        pushButton_28->setGeometry(QRect(40, 180, 71, 51));
        pushButton_28->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_29 = new QPushButton(groupBox_2);
        pushButton_29->setObjectName(QStringLiteral("pushButton_29"));
        pushButton_29->setGeometry(QRect(40, 360, 71, 51));
        pushButton_29->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        pushButton_30 = new QPushButton(groupBox_2);
        pushButton_30->setObjectName(QStringLiteral("pushButton_30"));
        pushButton_30->setGeometry(QRect(10, 210, 21, 23));
        pushButton_31 = new QPushButton(groupBox_2);
        pushButton_31->setObjectName(QStringLiteral("pushButton_31"));
        pushButton_31->setGeometry(QRect(110, 60, 20, 20));
        pushButton_32 = new QPushButton(groupBox_2);
        pushButton_32->setObjectName(QStringLiteral("pushButton_32"));
        pushButton_32->setGeometry(QRect(40, 240, 71, 51));
        pushButton_32->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        Floor2_1 = new QPushButton(groupBox_2);
        Floor2_1->setObjectName(QStringLiteral("Floor2_1"));
        Floor2_1->setGeometry(QRect(20, 30, 20, 20));
        pushButton_34 = new QPushButton(groupBox_2);
        pushButton_34->setObjectName(QStringLiteral("pushButton_34"));
        pushButton_34->setGeometry(QRect(10, 240, 21, 23));
        pushButton_35 = new QPushButton(groupBox_2);
        pushButton_35->setObjectName(QStringLiteral("pushButton_35"));
        pushButton_35->setGeometry(QRect(20, 60, 20, 20));
        pushButton_36 = new QPushButton(groupBox_2);
        pushButton_36->setObjectName(QStringLiteral("pushButton_36"));
        pushButton_36->setGeometry(QRect(40, 120, 71, 51));
        pushButton_36->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_37 = new QPushButton(groupBox_2);
        pushButton_37->setObjectName(QStringLiteral("pushButton_37"));
        pushButton_37->setGeometry(QRect(10, 180, 21, 23));
        Floor2_2 = new QPushButton(groupBox_2);
        Floor2_2->setObjectName(QStringLiteral("Floor2_2"));
        Floor2_2->setGeometry(QRect(50, 30, 20, 20));
        pushButton_39 = new QPushButton(groupBox_2);
        pushButton_39->setObjectName(QStringLiteral("pushButton_39"));
        pushButton_39->setGeometry(QRect(80, 60, 20, 20));
        lcdNumber_10 = new QLCDNumber(groupBox_2);
        lcdNumber_10->setObjectName(QStringLiteral("lcdNumber_10"));
        lcdNumber_10->setGeometry(QRect(120, 190, 25, 30));
        lcdNumber_10->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_10->setAutoFillBackground(false);
        lcdNumber_10->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_10->setSmallDecimalPoint(false);
        lcdNumber_10->setDigitCount(1);
        pushButton_40 = new QPushButton(groupBox_2);
        pushButton_40->setObjectName(QStringLiteral("pushButton_40"));
        pushButton_40->setGeometry(QRect(50, 60, 20, 20));
        NextButton2 = new QPushButton(groupBox_2);
        NextButton2->setObjectName(QStringLiteral("NextButton2"));
        NextButton2->setGeometry(QRect(40, 0, 75, 23));
        lcdNumber_11 = new QLCDNumber(groupBox_2);
        lcdNumber_11->setObjectName(QStringLiteral("lcdNumber_11"));
        lcdNumber_11->setGeometry(QRect(120, 130, 25, 30));
        lcdNumber_11->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_11->setAutoFillBackground(false);
        lcdNumber_11->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_11->setSmallDecimalPoint(false);
        lcdNumber_11->setDigitCount(1);
        lcdNumber_12 = new QLCDNumber(groupBox_2);
        lcdNumber_12->setObjectName(QStringLiteral("lcdNumber_12"));
        lcdNumber_12->setGeometry(QRect(120, 250, 25, 30));
        lcdNumber_12->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_12->setAutoFillBackground(false);
        lcdNumber_12->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_12->setSmallDecimalPoint(false);
        lcdNumber_12->setDigitCount(1);
        pushButton_42 = new QPushButton(groupBox_2);
        pushButton_42->setObjectName(QStringLiteral("pushButton_42"));
        pushButton_42->setGeometry(QRect(40, 300, 71, 51));
        pushButton_42->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));

        horizontalLayout->addWidget(groupBox_2);

        groupBox_5 = new QGroupBox(centralWidget);
        groupBox_5->setObjectName(QStringLiteral("groupBox_5"));
        lcd3_2 = new QLCDNumber(groupBox_5);
        lcd3_2->setObjectName(QStringLiteral("lcd3_2"));
        lcd3_2->setGeometry(QRect(120, 310, 25, 30));
        lcd3_2->setLayoutDirection(Qt::LeftToRight);
        lcd3_2->setAutoFillBackground(false);
        lcd3_2->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_2->setSmallDecimalPoint(false);
        lcd3_2->setDigitCount(1);
        FLOOR1U = new QPushButton(groupBox_5);
        FLOOR1U->setObjectName(QStringLiteral("FLOOR1U"));
        FLOOR1U->setGeometry(QRect(10, 370, 21, 23));
        FLOOR1U->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        FLOOR5D = new QPushButton(groupBox_5);
        FLOOR5D->setObjectName(QStringLiteral("FLOOR5D"));
        FLOOR5D->setGeometry(QRect(10, 130, 21, 23));
        FLOOR2U = new QPushButton(groupBox_5);
        FLOOR2U->setObjectName(QStringLiteral("FLOOR2U"));
        FLOOR2U->setGeometry(QRect(10, 300, 21, 23));
        lcd3_1 = new QLCDNumber(groupBox_5);
        lcd3_1->setObjectName(QStringLiteral("lcd3_1"));
        lcd3_1->setGeometry(QRect(120, 370, 25, 30));
        lcd3_1->setLayoutDirection(Qt::LeftToRight);
        lcd3_1->setAutoFillBackground(false);
        lcd3_1->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_1->setSmallDecimalPoint(false);
        lcd3_1->setDigitCount(1);
        lcd3_1->setProperty("value", QVariant(0));
        lcd3_1->setProperty("intValue", QVariant(0));
        lcd3_6 = new QLCDNumber(groupBox_5);
        lcd3_6->setObjectName(QStringLiteral("lcd3_6"));
        lcd3_6->setGeometry(QRect(120, 30, 25, 30));
        lcd3_6->setLayoutDirection(Qt::LeftToRight);
        lcd3_6->setAutoFillBackground(false);
        lcd3_6->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_6->setSmallDecimalPoint(false);
        lcd3_6->setDigitCount(1);
        Floor3_3 = new QPushButton(groupBox_5);
        Floor3_3->setObjectName(QStringLiteral("Floor3_3"));
        Floor3_3->setGeometry(QRect(80, 30, 20, 20));
        FLOOR3D = new QPushButton(groupBox_5);
        FLOOR3D->setObjectName(QStringLiteral("FLOOR3D"));
        FLOOR3D->setGeometry(QRect(10, 270, 21, 23));
        FLOOR2D = new QPushButton(groupBox_5);
        FLOOR2D->setObjectName(QStringLiteral("FLOOR2D"));
        FLOOR2D->setGeometry(QRect(10, 330, 21, 23));
        FLOOR4 = new QPushButton(groupBox_5);
        FLOOR4->setObjectName(QStringLiteral("FLOOR4"));
        FLOOR4->setGeometry(QRect(40, 180, 71, 51));
        FLOOR4->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        FLOOR1 = new QPushButton(groupBox_5);
        FLOOR1->setObjectName(QStringLiteral("FLOOR1"));
        FLOOR1->setGeometry(QRect(40, 360, 71, 51));
        FLOOR1->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        FLOOR4D = new QPushButton(groupBox_5);
        FLOOR4D->setObjectName(QStringLiteral("FLOOR4D"));
        FLOOR4D->setGeometry(QRect(10, 210, 21, 23));
        Floor3_E = new QPushButton(groupBox_5);
        Floor3_E->setObjectName(QStringLiteral("Floor3_E"));
        Floor3_E->setGeometry(QRect(110, 60, 20, 20));
        FLOOR3 = new QPushButton(groupBox_5);
        FLOOR3->setObjectName(QStringLiteral("FLOOR3"));
        FLOOR3->setGeometry(QRect(40, 240, 71, 51));
        FLOOR3->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        Floor3_1 = new QPushButton(groupBox_5);
        Floor3_1->setObjectName(QStringLiteral("Floor3_1"));
        Floor3_1->setGeometry(QRect(20, 30, 20, 20));
        FLOOR3U = new QPushButton(groupBox_5);
        FLOOR3U->setObjectName(QStringLiteral("FLOOR3U"));
        FLOOR3U->setGeometry(QRect(10, 240, 21, 23));
        Floor3_4 = new QPushButton(groupBox_5);
        Floor3_4->setObjectName(QStringLiteral("Floor3_4"));
        Floor3_4->setGeometry(QRect(20, 60, 20, 20));
        FLOOR5 = new QPushButton(groupBox_5);
        FLOOR5->setObjectName(QStringLiteral("FLOOR5"));
        FLOOR5->setGeometry(QRect(40, 120, 71, 51));
        FLOOR5->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        FLOOR4U = new QPushButton(groupBox_5);
        FLOOR4U->setObjectName(QStringLiteral("FLOOR4U"));
        FLOOR4U->setGeometry(QRect(10, 180, 21, 23));
        Floor3_2 = new QPushButton(groupBox_5);
        Floor3_2->setObjectName(QStringLiteral("Floor3_2"));
        Floor3_2->setGeometry(QRect(50, 30, 20, 20));
        Floor3_A = new QPushButton(groupBox_5);
        Floor3_A->setObjectName(QStringLiteral("Floor3_A"));
        Floor3_A->setGeometry(QRect(80, 60, 20, 20));
        lcd3_4 = new QLCDNumber(groupBox_5);
        lcd3_4->setObjectName(QStringLiteral("lcd3_4"));
        lcd3_4->setGeometry(QRect(120, 190, 25, 30));
        lcd3_4->setLayoutDirection(Qt::LeftToRight);
        lcd3_4->setAutoFillBackground(false);
        lcd3_4->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_4->setSmallDecimalPoint(false);
        lcd3_4->setDigitCount(1);
        Floor3_5 = new QPushButton(groupBox_5);
        Floor3_5->setObjectName(QStringLiteral("Floor3_5"));
        Floor3_5->setGeometry(QRect(50, 60, 20, 20));
        NextButton3 = new QPushButton(groupBox_5);
        NextButton3->setObjectName(QStringLiteral("NextButton3"));
        NextButton3->setGeometry(QRect(40, 0, 75, 23));
        lcd3_5 = new QLCDNumber(groupBox_5);
        lcd3_5->setObjectName(QStringLiteral("lcd3_5"));
        lcd3_5->setGeometry(QRect(120, 130, 25, 30));
        lcd3_5->setLayoutDirection(Qt::LeftToRight);
        lcd3_5->setAutoFillBackground(false);
        lcd3_5->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_5->setSmallDecimalPoint(false);
        lcd3_5->setDigitCount(1);
        lcd3_3 = new QLCDNumber(groupBox_5);
        lcd3_3->setObjectName(QStringLiteral("lcd3_3"));
        lcd3_3->setGeometry(QRect(120, 250, 25, 30));
        lcd3_3->setLayoutDirection(Qt::LeftToRight);
        lcd3_3->setAutoFillBackground(false);
        lcd3_3->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd3_3->setSmallDecimalPoint(false);
        lcd3_3->setDigitCount(1);
        FLOOR2 = new QPushButton(groupBox_5);
        FLOOR2->setObjectName(QStringLiteral("FLOOR2"));
        FLOOR2->setGeometry(QRect(40, 300, 71, 51));
        FLOOR2->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));

        horizontalLayout->addWidget(groupBox_5);

        groupBox_6 = new QGroupBox(centralWidget);
        groupBox_6->setObjectName(QStringLiteral("groupBox_6"));
        lcdNumber_19 = new QLCDNumber(groupBox_6);
        lcdNumber_19->setObjectName(QStringLiteral("lcdNumber_19"));
        lcdNumber_19->setGeometry(QRect(120, 310, 25, 30));
        lcdNumber_19->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_19->setAutoFillBackground(false);
        lcdNumber_19->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_19->setSmallDecimalPoint(false);
        lcdNumber_19->setDigitCount(1);
        pushButton_64 = new QPushButton(groupBox_6);
        pushButton_64->setObjectName(QStringLiteral("pushButton_64"));
        pushButton_64->setGeometry(QRect(10, 370, 21, 23));
        pushButton_64->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        pushButton_65 = new QPushButton(groupBox_6);
        pushButton_65->setObjectName(QStringLiteral("pushButton_65"));
        pushButton_65->setGeometry(QRect(10, 130, 21, 23));
        pushButton_66 = new QPushButton(groupBox_6);
        pushButton_66->setObjectName(QStringLiteral("pushButton_66"));
        pushButton_66->setGeometry(QRect(10, 300, 21, 23));
        lcdNumber_20 = new QLCDNumber(groupBox_6);
        lcdNumber_20->setObjectName(QStringLiteral("lcdNumber_20"));
        lcdNumber_20->setGeometry(QRect(120, 370, 25, 30));
        lcdNumber_20->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_20->setAutoFillBackground(false);
        lcdNumber_20->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_20->setSmallDecimalPoint(false);
        lcdNumber_20->setDigitCount(1);
        lcdNumber_20->setProperty("value", QVariant(0));
        lcdNumber_20->setProperty("intValue", QVariant(0));
        lcdNumber_21 = new QLCDNumber(groupBox_6);
        lcdNumber_21->setObjectName(QStringLiteral("lcdNumber_21"));
        lcdNumber_21->setGeometry(QRect(120, 30, 25, 30));
        lcdNumber_21->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_21->setAutoFillBackground(false);
        lcdNumber_21->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_21->setSmallDecimalPoint(false);
        lcdNumber_21->setDigitCount(1);
        pushButton_67 = new QPushButton(groupBox_6);
        pushButton_67->setObjectName(QStringLiteral("pushButton_67"));
        pushButton_67->setGeometry(QRect(80, 30, 20, 20));
        pushButton_68 = new QPushButton(groupBox_6);
        pushButton_68->setObjectName(QStringLiteral("pushButton_68"));
        pushButton_68->setGeometry(QRect(10, 270, 21, 23));
        pushButton_69 = new QPushButton(groupBox_6);
        pushButton_69->setObjectName(QStringLiteral("pushButton_69"));
        pushButton_69->setGeometry(QRect(10, 330, 21, 23));
        pushButton_70 = new QPushButton(groupBox_6);
        pushButton_70->setObjectName(QStringLiteral("pushButton_70"));
        pushButton_70->setGeometry(QRect(40, 180, 71, 51));
        pushButton_70->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_71 = new QPushButton(groupBox_6);
        pushButton_71->setObjectName(QStringLiteral("pushButton_71"));
        pushButton_71->setGeometry(QRect(40, 360, 71, 51));
        pushButton_71->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        pushButton_72 = new QPushButton(groupBox_6);
        pushButton_72->setObjectName(QStringLiteral("pushButton_72"));
        pushButton_72->setGeometry(QRect(10, 210, 21, 23));
        pushButton_73 = new QPushButton(groupBox_6);
        pushButton_73->setObjectName(QStringLiteral("pushButton_73"));
        pushButton_73->setGeometry(QRect(110, 60, 20, 20));
        pushButton_74 = new QPushButton(groupBox_6);
        pushButton_74->setObjectName(QStringLiteral("pushButton_74"));
        pushButton_74->setGeometry(QRect(40, 240, 71, 51));
        pushButton_74->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_75 = new QPushButton(groupBox_6);
        pushButton_75->setObjectName(QStringLiteral("pushButton_75"));
        pushButton_75->setGeometry(QRect(20, 30, 20, 20));
        pushButton_76 = new QPushButton(groupBox_6);
        pushButton_76->setObjectName(QStringLiteral("pushButton_76"));
        pushButton_76->setGeometry(QRect(10, 240, 21, 23));
        pushButton_77 = new QPushButton(groupBox_6);
        pushButton_77->setObjectName(QStringLiteral("pushButton_77"));
        pushButton_77->setGeometry(QRect(20, 60, 20, 20));
        pushButton_78 = new QPushButton(groupBox_6);
        pushButton_78->setObjectName(QStringLiteral("pushButton_78"));
        pushButton_78->setGeometry(QRect(40, 120, 71, 51));
        pushButton_78->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_79 = new QPushButton(groupBox_6);
        pushButton_79->setObjectName(QStringLiteral("pushButton_79"));
        pushButton_79->setGeometry(QRect(10, 180, 21, 23));
        pushButton_80 = new QPushButton(groupBox_6);
        pushButton_80->setObjectName(QStringLiteral("pushButton_80"));
        pushButton_80->setGeometry(QRect(50, 30, 20, 20));
        pushButton_81 = new QPushButton(groupBox_6);
        pushButton_81->setObjectName(QStringLiteral("pushButton_81"));
        pushButton_81->setGeometry(QRect(80, 60, 20, 20));
        lcdNumber_22 = new QLCDNumber(groupBox_6);
        lcdNumber_22->setObjectName(QStringLiteral("lcdNumber_22"));
        lcdNumber_22->setGeometry(QRect(120, 190, 25, 30));
        lcdNumber_22->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_22->setAutoFillBackground(false);
        lcdNumber_22->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_22->setSmallDecimalPoint(false);
        lcdNumber_22->setDigitCount(1);
        pushButton_82 = new QPushButton(groupBox_6);
        pushButton_82->setObjectName(QStringLiteral("pushButton_82"));
        pushButton_82->setGeometry(QRect(50, 60, 20, 20));
        pushButton_83 = new QPushButton(groupBox_6);
        pushButton_83->setObjectName(QStringLiteral("pushButton_83"));
        pushButton_83->setGeometry(QRect(40, 0, 75, 23));
        lcdNumber_23 = new QLCDNumber(groupBox_6);
        lcdNumber_23->setObjectName(QStringLiteral("lcdNumber_23"));
        lcdNumber_23->setGeometry(QRect(120, 130, 25, 30));
        lcdNumber_23->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_23->setAutoFillBackground(false);
        lcdNumber_23->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_23->setSmallDecimalPoint(false);
        lcdNumber_23->setDigitCount(1);
        lcdNumber_24 = new QLCDNumber(groupBox_6);
        lcdNumber_24->setObjectName(QStringLiteral("lcdNumber_24"));
        lcdNumber_24->setGeometry(QRect(120, 250, 25, 30));
        lcdNumber_24->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_24->setAutoFillBackground(false);
        lcdNumber_24->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_24->setSmallDecimalPoint(false);
        lcdNumber_24->setDigitCount(1);
        pushButton_84 = new QPushButton(groupBox_6);
        pushButton_84->setObjectName(QStringLiteral("pushButton_84"));
        pushButton_84->setGeometry(QRect(40, 300, 71, 51));
        pushButton_84->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));

        horizontalLayout->addWidget(groupBox_6);

        groupBox = new QGroupBox(centralWidget);
        groupBox->setObjectName(QStringLiteral("groupBox"));
        lcd5_2 = new QLCDNumber(groupBox);
        lcd5_2->setObjectName(QStringLiteral("lcd5_2"));
        lcd5_2->setGeometry(QRect(120, 310, 25, 30));
        lcd5_2->setLayoutDirection(Qt::LeftToRight);
        lcd5_2->setAutoFillBackground(false);
        lcd5_2->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_2->setSmallDecimalPoint(false);
        lcd5_2->setDigitCount(1);
        FLOOR51U = new QPushButton(groupBox);
        FLOOR51U->setObjectName(QStringLiteral("FLOOR51U"));
        FLOOR51U->setGeometry(QRect(10, 370, 21, 23));
        FLOOR51U->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        FLOOR55D = new QPushButton(groupBox);
        FLOOR55D->setObjectName(QStringLiteral("FLOOR55D"));
        FLOOR55D->setGeometry(QRect(10, 130, 21, 23));
        FLOOR52U = new QPushButton(groupBox);
        FLOOR52U->setObjectName(QStringLiteral("FLOOR52U"));
        FLOOR52U->setGeometry(QRect(10, 300, 21, 23));
        lcd5_1 = new QLCDNumber(groupBox);
        lcd5_1->setObjectName(QStringLiteral("lcd5_1"));
        lcd5_1->setGeometry(QRect(120, 370, 25, 30));
        lcd5_1->setLayoutDirection(Qt::LeftToRight);
        lcd5_1->setAutoFillBackground(false);
        lcd5_1->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_1->setSmallDecimalPoint(false);
        lcd5_1->setDigitCount(1);
        lcd5_1->setProperty("value", QVariant(0));
        lcd5_1->setProperty("intValue", QVariant(0));
        lcd5_6 = new QLCDNumber(groupBox);
        lcd5_6->setObjectName(QStringLiteral("lcd5_6"));
        lcd5_6->setGeometry(QRect(120, 30, 25, 30));
        lcd5_6->setLayoutDirection(Qt::LeftToRight);
        lcd5_6->setAutoFillBackground(false);
        lcd5_6->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_6->setSmallDecimalPoint(false);
        lcd5_6->setDigitCount(1);
        Floor5_3 = new QPushButton(groupBox);
        Floor5_3->setObjectName(QStringLiteral("Floor5_3"));
        Floor5_3->setGeometry(QRect(80, 30, 20, 20));
        FLOOR53D = new QPushButton(groupBox);
        FLOOR53D->setObjectName(QStringLiteral("FLOOR53D"));
        FLOOR53D->setGeometry(QRect(10, 270, 21, 23));
        FLOOR52D = new QPushButton(groupBox);
        FLOOR52D->setObjectName(QStringLiteral("FLOOR52D"));
        FLOOR52D->setGeometry(QRect(10, 330, 21, 23));
        FLOOR54 = new QPushButton(groupBox);
        FLOOR54->setObjectName(QStringLiteral("FLOOR54"));
        FLOOR54->setGeometry(QRect(40, 180, 71, 51));
        FLOOR54->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        FLOOR51 = new QPushButton(groupBox);
        FLOOR51->setObjectName(QStringLiteral("FLOOR51"));
        FLOOR51->setGeometry(QRect(40, 360, 71, 51));
        FLOOR51->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        FLOOR54D = new QPushButton(groupBox);
        FLOOR54D->setObjectName(QStringLiteral("FLOOR54D"));
        FLOOR54D->setGeometry(QRect(10, 210, 21, 23));
        Floor5_E = new QPushButton(groupBox);
        Floor5_E->setObjectName(QStringLiteral("Floor5_E"));
        Floor5_E->setGeometry(QRect(110, 60, 20, 20));
        FLOOR53 = new QPushButton(groupBox);
        FLOOR53->setObjectName(QStringLiteral("FLOOR53"));
        FLOOR53->setGeometry(QRect(40, 240, 71, 51));
        FLOOR53->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        Floor5_1 = new QPushButton(groupBox);
        Floor5_1->setObjectName(QStringLiteral("Floor5_1"));
        Floor5_1->setGeometry(QRect(20, 30, 20, 20));
        FLOOR53U = new QPushButton(groupBox);
        FLOOR53U->setObjectName(QStringLiteral("FLOOR53U"));
        FLOOR53U->setGeometry(QRect(10, 240, 21, 23));
        Floor5_4 = new QPushButton(groupBox);
        Floor5_4->setObjectName(QStringLiteral("Floor5_4"));
        Floor5_4->setGeometry(QRect(20, 60, 20, 20));
        FLOOR55 = new QPushButton(groupBox);
        FLOOR55->setObjectName(QStringLiteral("FLOOR55"));
        FLOOR55->setGeometry(QRect(40, 120, 71, 51));
        FLOOR55->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        FLOOR54U = new QPushButton(groupBox);
        FLOOR54U->setObjectName(QStringLiteral("FLOOR54U"));
        FLOOR54U->setGeometry(QRect(10, 180, 21, 23));
        Floor5_2 = new QPushButton(groupBox);
        Floor5_2->setObjectName(QStringLiteral("Floor5_2"));
        Floor5_2->setGeometry(QRect(50, 30, 20, 20));
        Floor5_A = new QPushButton(groupBox);
        Floor5_A->setObjectName(QStringLiteral("Floor5_A"));
        Floor5_A->setGeometry(QRect(80, 60, 20, 20));
        lcd5_4 = new QLCDNumber(groupBox);
        lcd5_4->setObjectName(QStringLiteral("lcd5_4"));
        lcd5_4->setGeometry(QRect(120, 190, 25, 30));
        lcd5_4->setLayoutDirection(Qt::LeftToRight);
        lcd5_4->setAutoFillBackground(false);
        lcd5_4->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_4->setSmallDecimalPoint(false);
        lcd5_4->setDigitCount(1);
        Floor5_5 = new QPushButton(groupBox);
        Floor5_5->setObjectName(QStringLiteral("Floor5_5"));
        Floor5_5->setGeometry(QRect(50, 60, 20, 20));
        NextButton5 = new QPushButton(groupBox);
        NextButton5->setObjectName(QStringLiteral("NextButton5"));
        NextButton5->setGeometry(QRect(40, 0, 75, 23));
        lcd5_5 = new QLCDNumber(groupBox);
        lcd5_5->setObjectName(QStringLiteral("lcd5_5"));
        lcd5_5->setGeometry(QRect(120, 130, 25, 30));
        lcd5_5->setLayoutDirection(Qt::LeftToRight);
        lcd5_5->setAutoFillBackground(false);
        lcd5_5->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_5->setSmallDecimalPoint(false);
        lcd5_5->setDigitCount(1);
        lcd5_3 = new QLCDNumber(groupBox);
        lcd5_3->setObjectName(QStringLiteral("lcd5_3"));
        lcd5_3->setGeometry(QRect(120, 250, 25, 30));
        lcd5_3->setLayoutDirection(Qt::LeftToRight);
        lcd5_3->setAutoFillBackground(false);
        lcd5_3->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcd5_3->setSmallDecimalPoint(false);
        lcd5_3->setDigitCount(1);
        FLOOR52 = new QPushButton(groupBox);
        FLOOR52->setObjectName(QStringLiteral("FLOOR52"));
        FLOOR52->setGeometry(QRect(40, 300, 71, 51));
        FLOOR52->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));

        horizontalLayout->addWidget(groupBox);

        groupBox_4 = new QGroupBox(centralWidget);
        groupBox_4->setObjectName(QStringLiteral("groupBox_4"));
        lcdNumber_37 = new QLCDNumber(groupBox_4);
        lcdNumber_37->setObjectName(QStringLiteral("lcdNumber_37"));
        lcdNumber_37->setGeometry(QRect(120, 310, 25, 30));
        lcdNumber_37->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_37->setAutoFillBackground(false);
        lcdNumber_37->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_37->setSmallDecimalPoint(false);
        lcdNumber_37->setDigitCount(1);
        pushButton_126 = new QPushButton(groupBox_4);
        pushButton_126->setObjectName(QStringLiteral("pushButton_126"));
        pushButton_126->setGeometry(QRect(10, 370, 21, 23));
        pushButton_126->setStyleSheet(QLatin1String("QPushButton:pressed {\n"
"background-color: red;\n"
"}"));
        pushButton_127 = new QPushButton(groupBox_4);
        pushButton_127->setObjectName(QStringLiteral("pushButton_127"));
        pushButton_127->setGeometry(QRect(10, 130, 21, 23));
        pushButton_128 = new QPushButton(groupBox_4);
        pushButton_128->setObjectName(QStringLiteral("pushButton_128"));
        pushButton_128->setGeometry(QRect(10, 300, 21, 23));
        lcdNumber_38 = new QLCDNumber(groupBox_4);
        lcdNumber_38->setObjectName(QStringLiteral("lcdNumber_38"));
        lcdNumber_38->setGeometry(QRect(120, 370, 25, 30));
        lcdNumber_38->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_38->setAutoFillBackground(false);
        lcdNumber_38->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_38->setSmallDecimalPoint(false);
        lcdNumber_38->setDigitCount(1);
        lcdNumber_38->setProperty("value", QVariant(0));
        lcdNumber_38->setProperty("intValue", QVariant(0));
        lcdNumber_39 = new QLCDNumber(groupBox_4);
        lcdNumber_39->setObjectName(QStringLiteral("lcdNumber_39"));
        lcdNumber_39->setGeometry(QRect(120, 30, 25, 30));
        lcdNumber_39->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_39->setAutoFillBackground(false);
        lcdNumber_39->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_39->setSmallDecimalPoint(false);
        lcdNumber_39->setDigitCount(1);
        pushButton_129 = new QPushButton(groupBox_4);
        pushButton_129->setObjectName(QStringLiteral("pushButton_129"));
        pushButton_129->setGeometry(QRect(80, 30, 20, 20));
        pushButton_130 = new QPushButton(groupBox_4);
        pushButton_130->setObjectName(QStringLiteral("pushButton_130"));
        pushButton_130->setGeometry(QRect(10, 270, 21, 23));
        pushButton_131 = new QPushButton(groupBox_4);
        pushButton_131->setObjectName(QStringLiteral("pushButton_131"));
        pushButton_131->setGeometry(QRect(10, 330, 21, 23));
        pushButton_132 = new QPushButton(groupBox_4);
        pushButton_132->setObjectName(QStringLiteral("pushButton_132"));
        pushButton_132->setGeometry(QRect(40, 180, 71, 51));
        pushButton_132->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_133 = new QPushButton(groupBox_4);
        pushButton_133->setObjectName(QStringLiteral("pushButton_133"));
        pushButton_133->setGeometry(QRect(40, 360, 71, 51));
        pushButton_133->setStyleSheet(QLatin1String("background-color:rgb(0, 170, 0);\n"
""));
        pushButton_134 = new QPushButton(groupBox_4);
        pushButton_134->setObjectName(QStringLiteral("pushButton_134"));
        pushButton_134->setGeometry(QRect(10, 210, 21, 23));
        pushButton_135 = new QPushButton(groupBox_4);
        pushButton_135->setObjectName(QStringLiteral("pushButton_135"));
        pushButton_135->setGeometry(QRect(110, 60, 20, 20));
        pushButton_136 = new QPushButton(groupBox_4);
        pushButton_136->setObjectName(QStringLiteral("pushButton_136"));
        pushButton_136->setGeometry(QRect(40, 240, 71, 51));
        pushButton_136->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_137 = new QPushButton(groupBox_4);
        pushButton_137->setObjectName(QStringLiteral("pushButton_137"));
        pushButton_137->setGeometry(QRect(20, 30, 20, 20));
        pushButton_138 = new QPushButton(groupBox_4);
        pushButton_138->setObjectName(QStringLiteral("pushButton_138"));
        pushButton_138->setGeometry(QRect(10, 240, 21, 23));
        pushButton_139 = new QPushButton(groupBox_4);
        pushButton_139->setObjectName(QStringLiteral("pushButton_139"));
        pushButton_139->setGeometry(QRect(20, 60, 20, 20));
        pushButton_140 = new QPushButton(groupBox_4);
        pushButton_140->setObjectName(QStringLiteral("pushButton_140"));
        pushButton_140->setGeometry(QRect(40, 120, 71, 51));
        pushButton_140->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));
        pushButton_141 = new QPushButton(groupBox_4);
        pushButton_141->setObjectName(QStringLiteral("pushButton_141"));
        pushButton_141->setGeometry(QRect(10, 180, 21, 23));
        pushButton_142 = new QPushButton(groupBox_4);
        pushButton_142->setObjectName(QStringLiteral("pushButton_142"));
        pushButton_142->setGeometry(QRect(50, 30, 20, 20));
        pushButton_143 = new QPushButton(groupBox_4);
        pushButton_143->setObjectName(QStringLiteral("pushButton_143"));
        pushButton_143->setGeometry(QRect(80, 60, 20, 20));
        lcdNumber_40 = new QLCDNumber(groupBox_4);
        lcdNumber_40->setObjectName(QStringLiteral("lcdNumber_40"));
        lcdNumber_40->setGeometry(QRect(120, 190, 25, 30));
        lcdNumber_40->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_40->setAutoFillBackground(false);
        lcdNumber_40->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_40->setSmallDecimalPoint(false);
        lcdNumber_40->setDigitCount(1);
        pushButton_144 = new QPushButton(groupBox_4);
        pushButton_144->setObjectName(QStringLiteral("pushButton_144"));
        pushButton_144->setGeometry(QRect(50, 60, 20, 20));
        pushButton_145 = new QPushButton(groupBox_4);
        pushButton_145->setObjectName(QStringLiteral("pushButton_145"));
        pushButton_145->setGeometry(QRect(40, 0, 75, 23));
        lcdNumber_41 = new QLCDNumber(groupBox_4);
        lcdNumber_41->setObjectName(QStringLiteral("lcdNumber_41"));
        lcdNumber_41->setGeometry(QRect(120, 130, 25, 30));
        lcdNumber_41->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_41->setAutoFillBackground(false);
        lcdNumber_41->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_41->setSmallDecimalPoint(false);
        lcdNumber_41->setDigitCount(1);
        lcdNumber_42 = new QLCDNumber(groupBox_4);
        lcdNumber_42->setObjectName(QStringLiteral("lcdNumber_42"));
        lcdNumber_42->setGeometry(QRect(120, 250, 25, 30));
        lcdNumber_42->setLayoutDirection(Qt::LeftToRight);
        lcdNumber_42->setAutoFillBackground(false);
        lcdNumber_42->setStyleSheet(QLatin1String("colour:red;\n"
"font: 12pt \"MS Shell Dlg 2\";"));
        lcdNumber_42->setSmallDecimalPoint(false);
        lcdNumber_42->setDigitCount(1);
        pushButton_146 = new QPushButton(groupBox_4);
        pushButton_146->setObjectName(QStringLiteral("pushButton_146"));
        pushButton_146->setGeometry(QRect(40, 300, 71, 51));
        pushButton_146->setStyleSheet(QStringLiteral("background-color:rgb(200, 144, 13);"));

        horizontalLayout->addWidget(groupBox_4);

        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 980, 21));
        menuElevator_Management_System = new QMenu(menuBar);
        menuElevator_Management_System->setObjectName(QStringLiteral("menuElevator_Management_System"));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QStringLiteral("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        MainWindow->setStatusBar(statusBar);

        menuBar->addAction(menuElevator_Management_System->menuAction());

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        groupBox_3->setTitle(QApplication::translate("MainWindow", "Lift 1", nullptr));
        pushButton_3->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        pushButton_4->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_5->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        pushButton_6->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_7->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        pushButton_8->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_9->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        pushButton_2->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        pushButton->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_11->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_12->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_13->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_14->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_15->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_16->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_17->setText(QApplication::translate("MainWindow", "5", nullptr));
        pushButton_18->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_19->setText(QApplication::translate("MainWindow", "A", nullptr));
        pushButton_20->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_21->setText(QApplication::translate("MainWindow", "E", nullptr));
        pushButton_10->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        pushButton_10->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        groupBox_2->setTitle(QApplication::translate("MainWindow", "Lift 2", nullptr));
        pushButton_22->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_23->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_24->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_25->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_26->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_27->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_28->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        pushButton_29->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        pushButton_30->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_31->setText(QApplication::translate("MainWindow", "E", nullptr));
        pushButton_32->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        Floor2_1->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_34->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_35->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_36->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        pushButton_37->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor2_2->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_39->setText(QApplication::translate("MainWindow", "A", nullptr));
        pushButton_40->setText(QApplication::translate("MainWindow", "5", nullptr));
        NextButton2->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        NextButton2->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        pushButton_42->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        groupBox_5->setTitle(QApplication::translate("MainWindow", "Lift 3", nullptr));
        FLOOR1U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        FLOOR5D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR2U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor3_3->setText(QApplication::translate("MainWindow", "3", nullptr));
        FLOOR3D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR2D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR4->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        FLOOR1->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        FLOOR4D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        Floor3_E->setText(QApplication::translate("MainWindow", "E", nullptr));
        FLOOR3->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        Floor3_1->setText(QApplication::translate("MainWindow", "1", nullptr));
        FLOOR3U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor3_4->setText(QApplication::translate("MainWindow", "4", nullptr));
        FLOOR5->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        FLOOR4U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor3_2->setText(QApplication::translate("MainWindow", "2", nullptr));
        Floor3_A->setText(QApplication::translate("MainWindow", "A", nullptr));
        Floor3_5->setText(QApplication::translate("MainWindow", "5", nullptr));
        NextButton3->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        NextButton3->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        FLOOR2->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        groupBox_6->setTitle(QApplication::translate("MainWindow", "Lift 4", nullptr));
        pushButton_64->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_65->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_66->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_67->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_68->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_69->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_70->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        pushButton_71->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        pushButton_72->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_73->setText(QApplication::translate("MainWindow", "E", nullptr));
        pushButton_74->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        pushButton_75->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_76->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_77->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_78->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        pushButton_79->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_80->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_81->setText(QApplication::translate("MainWindow", "A", nullptr));
        pushButton_82->setText(QApplication::translate("MainWindow", "5", nullptr));
        pushButton_83->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        pushButton_83->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        pushButton_84->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        groupBox->setTitle(QApplication::translate("MainWindow", "Lift 5", nullptr));
        FLOOR51U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        FLOOR55D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR52U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor5_3->setText(QApplication::translate("MainWindow", "3", nullptr));
        FLOOR53D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR52D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        FLOOR54->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        FLOOR51->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        FLOOR54D->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        Floor5_E->setText(QApplication::translate("MainWindow", "E", nullptr));
        FLOOR53->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        Floor5_1->setText(QApplication::translate("MainWindow", "1", nullptr));
        FLOOR53U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor5_4->setText(QApplication::translate("MainWindow", "4", nullptr));
        FLOOR55->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        FLOOR54U->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        Floor5_2->setText(QApplication::translate("MainWindow", "2", nullptr));
        Floor5_A->setText(QApplication::translate("MainWindow", "A", nullptr));
        Floor5_5->setText(QApplication::translate("MainWindow", "5", nullptr));
        NextButton5->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        NextButton5->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        FLOOR52->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        groupBox_4->setTitle(QApplication::translate("MainWindow", "Lift 6", nullptr));
        pushButton_126->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_127->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_128->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_129->setText(QApplication::translate("MainWindow", "3", nullptr));
        pushButton_130->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_131->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_132->setText(QApplication::translate("MainWindow", "Floor 4", nullptr));
        pushButton_133->setText(QApplication::translate("MainWindow", "Floor 1", nullptr));
        pushButton_134->setText(QApplication::translate("MainWindow", "\342\206\223", nullptr));
        pushButton_135->setText(QApplication::translate("MainWindow", "E", nullptr));
        pushButton_136->setText(QApplication::translate("MainWindow", "Floor 3", nullptr));
        pushButton_137->setText(QApplication::translate("MainWindow", "1", nullptr));
        pushButton_138->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_139->setText(QApplication::translate("MainWindow", "4", nullptr));
        pushButton_140->setText(QApplication::translate("MainWindow", "Floor 5", nullptr));
        pushButton_141->setText(QApplication::translate("MainWindow", "\342\206\221", nullptr));
        pushButton_142->setText(QApplication::translate("MainWindow", "2", nullptr));
        pushButton_143->setText(QApplication::translate("MainWindow", "A", nullptr));
        pushButton_144->setText(QApplication::translate("MainWindow", "5", nullptr));
        pushButton_145->setText(QApplication::translate("MainWindow", "Next", nullptr));
#ifndef QT_NO_SHORTCUT
        pushButton_145->setShortcut(QApplication::translate("MainWindow", "Enter", nullptr));
#endif // QT_NO_SHORTCUT
        pushButton_146->setText(QApplication::translate("MainWindow", "Floor 2", nullptr));
        menuElevator_Management_System->setTitle(QApplication::translate("MainWindow", "Elevator Management System", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
